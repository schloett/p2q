require(['./common'], function(common) {
    require(['c4/APIconnector', 'up/profileManager', 'util', 'c4/namedEntityRecognition'], function(APIconnector, profileManager, util, ner) {
//        APIconnector.init({base_url:'http://eexcess-dev.joanneum.at/eexcess-privacy-proxy-1.0-SNAPSHOT/api/v1/'});
//        APIconnector.init({base_url:'http://eexcess-dev.joanneum.at/eexcess-federated-recommender-web-service-1.0-SNAPSHOT/recommender/'});
//        APIconnector.init({base_url:'http://eexcess-demo.know-center.tugraz.at/eexcess-federated-recommender-web-service-1.0-SNAPSHOT/recommender/'});
//        var serverURL = 'http://localhost:8080/relevantico/api/';
        var serverURL = 'http://zaire.dimis.fim.uni-passau.de:8087/RELEVANTICO/api/';
//        var serverURL = 'https://eexcess-dev.joanneum.at/eexcess-privacy-proxy-issuer-1.0-SNAPSHOT/issuer/';
        APIconnector.init({base_url: serverURL});
        var msgAllTabs = function(msg) {
            chrome.tabs.query({}, function(tabs) {
                for (var i = 0, len = tabs.length; i < len; i++) {
                    chrome.tabs.sendMessage(tabs[i].id, msg);
                }
            });
        };

        var paragraphID;
        var queryID;
        var page;

        var selectedSources = [];
        var qcHistory = localStorage.getItem('qcHistory');
        if (typeof qcHistory !== 'undefined') {
            qcHistory = JSON.parse(qcHistory);
        }

        chrome.storage.sync.get(['numResults', 'selectedSources', 'uuid'], function(result) {
            if (result.selectedSources) {
                result.selectedSources.forEach(function(val) {
                    selectedSources.push({systemId: val.systemId});
                });
            }
            var uuid;
            if (result.uuid) {
                uuid = result.uuid;
            } else {
                uuid = util.randomUUID();
                chrome.storage.sync.set({uuid: uuid});
            }
            var manifest = chrome.runtime.getManifest();
            var settings = {origin: {
                    userID: uuid,
                    clientType: manifest.name + "/chrome-extension",
                    clientVersion: manifest.version
                }};
            if (result.numResults) {
                settings.numResults = result.numResults;
            }
            APIconnector.init(settings);

            chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
                if (typeof msg.method !== 'undefined') {
                    switch (msg.method) {
                        case 'triggerQuery':
                            var profile = msg.data;
                            // selected sources
                            if (selectedSources && selectedSources.length > 0 && !profile.partnerList) {
                                profile.partnerList = selectedSources;
                            }
                            // Adaptation of the profile according to the policies
                            console.log(profile);
                            var timestamp = new Date().getTime();
                            queryID = settings.origin.userID + timestamp;
                            profile.queryID = queryID;
                            profile.paragraphID = paragraphID;
                            profile.timestamp = timestamp;
                            profile.page = page;
                            APIconnector.query(profile, sendResponse);

                            return true;
                            break;
                        case 'optionsUpdate':
                            chrome.storage.sync.get(['numResults', 'selectedSources'], function(result) {
                                if (result.numResults) {
                                    APIconnector.setNumResults(result.numResults);
                                }
                                if (result.selectedSources) {
                                    selectedSources = [];
                                    result.selectedSources.forEach(function(val) {
                                        selectedSources.push({systemId: val.systemId});
                                    });
                                }
                            });
                            break;
                        case 'updateQueryCrumbs':
                            msgAllTabs(msg);
                            break;
                        case 'qcGetHistory':
                            sendResponse(qcHistory);
                            return true;
                            break;
                        case 'qcSetHistory':
                            qcHistory = msg.data;
                            localStorage.setItem('qcHistory', JSON.stringify(qcHistory));
                            break;
                        case 'ner':
                            ner.entitiesAndCategories(msg.data, sendResponse);
                            return true;
                            break;
                        case 'logParagraph':
                            var timestamp = new Date().getTime();
                            paragraphID = settings.origin.userID + timestamp;
                            msg.data.paragraphID = paragraphID;
                            msg.data.userID = settings.origin.userID;
                            msg.data.timestamp = timestamp;
                            msg.data.page = page;
                            $.ajax({
                                url: serverURL + 'logParagraph',
                                data: JSON.stringify(msg.data),
                                type: 'POST',
                                contentType: 'application/json; charset=UTF-8',
                                dataType: 'json'
                            });
                            break;
                        case 'rating':
                            msg.data.queryID = queryID;
                            msg.data.paragraphID = paragraphID;
                            msg.data.userID = settings.origin.userID;
                            msg.data.timestamp = new Date().getTime();
                            msg.data.page = page;
                            $.ajax({
                                url: serverURL + 'rating',
                                data: JSON.stringify(msg.data),
                                type: 'POST',
                                contentType: 'application/json; charset=UTF-8',
                                dataType: 'json'
                            });
                            break;
                        case 'details':
                            msg.data.queryID = queryID;
                            msg.data.paragraphID = paragraphID;
                            msg.data.userID = settings.origin.userID;
                            msg.data.timestamp = new Date().getTime();
                            msg.data.page = page;
                            $.ajax({
                                url: serverURL + 'details',
                                data: JSON.stringify(msg.data),
                                type: 'POST',
                                contentType: 'application/json; charset=UTF-8',
                                dataType: 'json'
                            });
                            break;
                        case 'queryAdaptation':
                            msg.data.paragraphID = paragraphID;
                            msg.data.userID = settings.origin.userID;
                            msg.data.timestamp = new Date().getTime();
                            msg.data.page = page;
                            $.ajax({
                                url: serverURL + 'queryAdaptation',
                                data: JSON.stringify(msg.data),
                                type: 'POST',
                                contentType: 'application/json; charset=UTF-8',
                                dataType: 'json'
                            });
                            break;
                        case 'page':
                            page = msg.data;
                            break;
                        default:
                            console.log('unknown method: ' + msg.method);
                            break;
                    }
                } else {
                    console.log('method not specified');
                }
            });
        });
    });
});